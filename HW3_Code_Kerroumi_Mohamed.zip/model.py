import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision import datasets, models, transforms
nclasses = 20

def freeze(model, block=2):
    modules = list(model.children())[:-1]
    for module in modules[:-block]:
        for p in module.parameters() : p.requires_grad = False
    return nn.Sequential(*modules)

class Net(nn.Module):
    def __init__(self):
        super(Net, self).__init__()
        self.model_ft= None
        self.model_ft = freeze(models.resnet18(pretrained=True), block=0)
        self.decision = nn.Linear(512,256)
        self.final = nn.Linear(256,nclasses)

    def forward(self, x):
        f = self.model_ft(x).view(-1,512)
        f = self.decision(f)
        output = self.final(f)
        return output




